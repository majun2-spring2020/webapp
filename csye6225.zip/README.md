# nodejs
## version: 10.18.1
# npm
## version:6.13.4
# LAMP
## reference: https://www.ostechnix.com/install-phpmyadmin-with-lamp-stack-on-ubuntu-18-04-lts/
# command:
* npm start
* npm test
* argv:
* * 2:mysql host
* * 3:mysql user
* * 4:mysql password
* * 5:mysql port
* * 6:mysql database
* * 7:S3    BUCKET
* * 8:aws   keyid
* * 9:aws   key