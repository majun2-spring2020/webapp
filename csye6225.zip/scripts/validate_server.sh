#!/bin/bash
sleep 60
curl http://localhost:3000