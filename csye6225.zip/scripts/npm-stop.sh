killall node || echo "no node"
killall npm || echo "no npm"